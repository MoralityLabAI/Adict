from addict_probe.bridge import load_runtime_trace_jsonl, rows_to_feature_matrix
import sys

if __name__ == '__main__':
    rows = load_runtime_trace_jsonl(sys.argv[1])
    x = rows_to_feature_matrix(rows)
    print({'rows': len(rows), 'feature_shape': tuple(x.shape)})
