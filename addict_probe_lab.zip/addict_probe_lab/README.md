# Addict Probe Lab

Addict Probe is a separate research repo for discovering sparse predictive motifs over workflow/control-plane traces.

This is intentionally separate from the runtime repo so you can:
- generate traces on a Mac or 3090 node
- ship traces between machines
- iterate on probe design independently of runtime wiring

## Relationship to Tesseract Control Runtime

The intended upstream runtime emits a stable trace language with fields such as:
- `ctx`
- `commit_state`
- `route_mask`
- `score`

Addict Probe consumes fixed-window versions of those traces and learns sparse atoms that predict drift, intervention need, and usefulness preservation.

## Repo focus

- trace windowing
- sparse dictionary probe baselines
- synthetic trace mode
- bridge docs for MLX/CUDA later

## Not required to start

You do not need real TRMs yet.
Placeholder slots and synthetic route semantics are enough.
